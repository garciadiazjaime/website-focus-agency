/*eslint-disable */
import React from 'react';
/*eslint-enable */
import { render } from 'react-dom';

import routes from '../shared/config/routes';


render(routes, document.getElementById('app'));
