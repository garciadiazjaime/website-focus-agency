export default [
  {
    image: '/images/focus-groups/slider/Logo-berumen.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-elinstituto.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-GDV.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-gfk.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-insitum.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-ipsos.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-iq.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-kp.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-lamarcalab.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-lexia.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-mb.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-nodo.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-nr.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-parametria.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-person.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-phenoma.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-qsolutions.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-serta.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-sigmados.jpg',
  }, {
    image: '/images/focus-groups/slider/logo-tns.jpg',
  },
];
