export default [
  {
    image: '/images/focus-groups/carousel/Focus-Camaragesell-01.png',
  }, {
    image: '/images/focus-groups/carousel/Focus-Camaragesell-02.png',
  }, {
    image: '/images/focus-groups/carousel/Focus-Camaragesell-03.png',
  }, {
    image: '/images/focus-groups/carousel/Focus-Camaragesell-04.png',
  }, {
    image: '/images/focus-groups/carousel/Focus-Camaragesell-05.png',
  }, {
    image: '/images/focus-groups/carousel/Focus-Camaragesell-06.png',
  }, {
    image: '/images/focus-groups/carousel/Focus-Camaragesell-07.png',
  },
];
