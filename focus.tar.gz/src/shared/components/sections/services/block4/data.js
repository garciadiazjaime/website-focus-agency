export default [
  {
    image: '/images/apoyo-logisitico/carousel/Focus-Infraestructura-01.png',
  }, {
    image: '/images/apoyo-logisitico/carousel/Focus-Infraestructura-02.png',
  }, {
    image: '/images/apoyo-logisitico/carousel/Focus-Infraestructura-03.png',
  }, {
    image: '/images/apoyo-logisitico/carousel/Focus-Infraestructura-04.png',
  }, {
    image: '/images/apoyo-logisitico/carousel/Focus-Infraestructura-05.png',
  }, {
    image: '/images/apoyo-logisitico/carousel/Focus-Infraestructura-06.png',
  },
];
