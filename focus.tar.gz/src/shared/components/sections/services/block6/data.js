export default [
  {
    image: '/images/apoyo-logisitico/slider/logo-acimsa.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/Logo-berumen.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-brain.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-elinstituto.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-evidens.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-gfk.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-inmega.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-inmersa.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-ipsos.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-kp.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-marcaei.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-mb.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-more.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-nodo.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-ovalbox.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-parametria.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-serta.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-sigmados.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-tns.jpg',
  }, {
    image: '/images/apoyo-logisitico/slider/logo-wisdom.jpg',
  },
];
